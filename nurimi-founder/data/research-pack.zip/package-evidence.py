"""Package the evidence trail and calculated decision assumptions."""
from pathlib import Path
import json
import re
import shutil
import hashlib

HERE = Path(__file__).resolve().parent
RAW = Path(r'C:\Users\ahmed\AppData\Local\Temp\nurimi-commerce-research')

weights = {'launch_speed':18,'saudi_integration':18,'brand_flexibility':12,'arabic_rtl':10,
           'operational_reliability':12,'maintenance':10,'portability':8,'total_cost':12}
ratings = {
    'Salla native':[4,5,4,5,4,5,3,4],
    'Zid Vitrin':[4,5,4,5,4,4,3,3],
    'Shopify native':[4,3,5,4,4,4,4,3],
    'Shopify headless':[2,3,5,3,3,2,4,2],
    'Medusa custom':[1,2,5,3,2,1,5,2],
}


def score(r, w):
    return round(sum(a*b for a,b in zip(r,w.values())) / sum(w.values()) * 2, 3)


def main():
    evidence = HERE / 'evidence'
    evidence.mkdir(exist_ok=True)
    ledger = []
    for name in ('salla-zid','shopify-custom','saudi-market'):
        data = json.loads((RAW / f'{name}-sources.json').read_text(encoding='utf-8'))
        for s in data:
            ledger.append(dict(s, id=f"{name}:{s['id']}"))
        shutil.copy2(RAW / f'{name}-sources.json', evidence / f'{name}-sources.json')
        # Working research notes retained as evidence, not additional recommendations.
        shutil.copy2(RAW / f'{name}.md', evidence / f'{name}-working-notes.md')
    own = [
        ('Salla React overview','https://docs.salla.dev/twilight/react/start/what-is-a-theme','Managed React theme architecture; not a merchant acceptance test'),
        ('Salla framework availability','https://docs.salla.dev/twilight/react/start/frameworks','TanStack Start available, Next.js planned on research date'),
        ('Salla quick start','https://docs.salla.dev/twilight/react/start/quick-start','Documented tooling and local demo; runtime docs conflict with package README'),
        ('Salla React theme package','https://registry.npmjs.org/@salla.sa%2Ftheme-raed/1.0.63','Exact downloaded starter source and dependency metadata'),
        ('Salla CLI package','https://registry.npmjs.org/@salla.sa%2Fcli/3.2.63','CLI requires Node >=22.12.0'),
        ('Salla engine package','https://registry.npmjs.org/@salla.sa%2Ftwilight-theme-engine/1.0.133','Registry version captured; not clean-build validated'),
        ('Published esbuild metadata','https://registry.npmjs.org/esbuild/0.28.2','Independent npm lookup succeeded after transient pnpm metadata error'),
        ('Salla Twig source package','https://raw.githubusercontent.com/SallaApp/theme-raed/master/package.json','Current source dependency/runtime snapshot, not accepted merchant release'),
        ('Nice One investor results','https://ir.niceonesa.com/','Q2 2026 headline revenue and loss'),
        ('Nice One exchange announcement','https://www.saudiexchange.sa/wps/portal/saudiexchange/newsandreports/issuer-news/issuer-announcements/issuer-announcements-details/?anCat=1&anId=97016&cs=4193&locale=en','Published28July2026; Q2/H1results; indexed full text; direct reader returned403'),
        ('Core Web Vitals','https://developers.google.com/search/docs/appearance/core-web-vitals','Loading, interaction and layout metrics; field/lab distinction'),
        ('Salla React publication','https://docs.salla.dev/twilight/react/local-development/publish','Partner/repository/review gates; no authenticated publication performed'),
        ('Medusa release history','https://github.com/medusajs/medusa/releases','v2.22.0 current release and Node22.22.0+ requirement; use exact release notes'),
        ('SFDA port label FAQ HTTPS','https://www.sfda.gov.sa/ar/faq/60287','Label, INCI and exact variant checks; verify applicable product rules'),
        ('Shopify fee calculation','https://help.shopify.com/en/manual/your-account/manage-billing/your-invoice/charges#third-party-transaction-fees','Fee base includes products less discounts plus shipping and tax; region-specific refund treatment must be confirmed'),
    ]
    for i,(title,url,claim) in enumerate(own,1):
        ledger.append({'id':f'primary:{i}','title':title,'url':url,'accessed':'2026-10-27',
                       'published_updated':'live page unless noted','claims':[claim],
                       'limits':'Point-in-time source; does not establish merchant-specific acceptance or price.'})
    (HERE/'sources.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

    scenarios=[]
    for count in (1,3,5):
        cash=count*(2990+100+1200)
        labour=4*12*200+count*(1*12*200+1*12*100)
        scenarios.append({'stores':count,'annual_subscription_floor_sar':count*2990,
                          'annual_software_allowance_sar':cash,'annual_software_and_modelled_care_sar':cash+labour})
    sens_weights=dict(weights,saudi_integration=10,portability=16)
    model={
        'as_of':'2026-10-27','kind':'judgement_and_planning_assumptions_not_benchmark_or_quote',
        'weights_percent':weights,
        'scores':{name:{'criterion_scores':dict(zip(weights,r)), 'weighted_out_of_10':score(r,weights)} for name,r in ratings.items()},
        'sensitivity':{'case':'reduce local integration weight8points, add8 to portability',
                       'weights':sens_weights,'scores':{n:score(r,sens_weights) for n,r in ratings.items()}},
        'annual_cost_assumptions_sar':{'salla_pro_list':2990,'domain_planning':100,'apps_monitoring_allowance':1200,
             'engineering_hour_planning':200,'operations_hour_planning':100,
             'shared_engineering_hours_per_month':4,'per_store_engineering_hours_per_month':1,
             'per_store_operations_control_hours_per_month':1},
        'scenarios':scenarios,
        'first_store_hours':{'engineering':[72,112],'design_qa':[8,16],'operations':[16,32],'aggregate':[96,160]},
        'first_store_labour_sar':[72*200+8*150+16*100,112*200+16*150+32*100],
        'additional_brand_engineering_hours':[16,32],
        'owner_confirmed_context':{'merchant_setup':'not_confirmed','fulfilment':'Saudi stock/warehouse partner','warehouse_contract_and_performance':'not_verified'},
        'unit_economics_example':{'all_inputs_are_assumptions':True,'vat_registered':True,
              'gross_basket_sar':230,'net_sales_sar':200,'landed_cost_sar':110,'payment_cost_sar':5.6,
              'delivery_subsidy_sar':12,'pick_pack_sar':7,'packaging_sar':3,'return_spoilage_reserve_sar':6,
              'contribution_before_acquisition_sar':round(200-110-5.6-12-7-3-6,2),
              'cac_sar':45,'contribution_after_acquisition_sar':round(200-110-5.6-12-7-3-6-45,2)},
        'shopify_break_even':{'fx_planning_sar_per_usd':3.75,'annual_billed_monthly_difference_usd':35,
              'platform_fee_percentage_point_difference':1,'monthly_fee_bearing_value_sar':35*3.75/.01,
              'limits':'Same PSP rate assumed. Fee base includes tax/shipping. Excludes tax on subscription/FX effects.'},
        'unpriced':'tax treatment, theme entitlement, gateway contract, courier, warehouse, accounting/WMS, inventory, marketing, user research and new brand creation',
    }
    assert sum(weights.values())==100
    assert model['first_store_labour_sar']==[17200,28000]
    assert [s['annual_software_and_modelled_care_sar'] for s in scenarios]==[17490,33270,49050]
    (HERE/'decision-model.json').write_text(json.dumps(model,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

    package=RAW/'salla-raed/package'
    for name in ('package.json','README.md','vite.config.ts','twilight.json','LICENSE'):
        shutil.copy2(package/name,evidence/f'react-raed-{name}')
    graph=RAW/'code-audit/graphify-out/graph.json'
    shutil.copy2(graph,evidence/'source-dependency-graph.json')
    pkg=json.loads((package/'package.json').read_text())
    (evidence/'trial-status.json').write_text(json.dumps({
        'date':'2026-10-27','theme_version':pkg['version'],'theme_tarball_sha256':hashlib.sha256((RAW/'salla.sa-theme-raed-1.0.63.tgz').read_bytes()).hexdigest(),
        'cli_metadata_version':'3.2.63','engine_metadata_version':'1.0.133','system_node':'22.14.0',
        'available_bundled_node':'24.19.0','installed_pnpm':'11.21.0',
        'install_result':'registry timeouts/metadata errors; no successful clean installation claimed',
        'esbuild_0_28_2_independent_lookup':'exists; do not infer package defect from transient metadata failure',
        'build_passed':False,'merchant_auth_used':False,'orders_or_payments_executed':False,
        'shared_hooks_or_agent_kits_installed':False,
    },indent=2)+'\n')

    memo=HERE/'decision-memo.md'
    text=memo.read_text(encoding='utf-8')
    replacements={
        'CLI3.2.63':'CLI 3.2.63','Raed1.0.63':'Raed 1.0.63','engine1.0.133':'engine 1.0.133',
        'Node20.19':'Node 20.19','Node22.12':'Node 22.12','Node22.22':'Node 22.22',
        'as1.358.0':'as 1.358.0','covering23':'covering 23','Nineteen':'Nineteen',
        'time is5':'time is 5','tied to15':'tied to 15','basis, SAR':'basis, SAR',
        'care4h':'care 4h','technical1h':'technical 1h','work1h':'work 1h','plus8':'plus 8',
        'estimate16':'estimate 16','least4/5':'least 4/5','the75th':'the 75th','Q2/H1results':'Q2/H1 results',
        'first50':'first 50','Completed;23':'Completed; 23','variants,0':'variants, 0',
        'Graphify:82':'Graphify: 82','Completed;19':'Completed; 19','passed,0':'passed, 0',
        'day:27':'day: 27','Phase1':'Phase 1','Phase2':'Phase 2','June2026':'June 2026',
        'October2026':'October 2026','by one point':'by one percentage point',
        'at CAC45':'at CAC 45','8–16':'8–16',
    }
    # Avoid replacements inside URLs; prose cleanup only.
    parts=re.split(r'(https?://[^\s)]+)',text)
    for i in range(0,len(parts),2):
        for a,b in replacements.items(): parts[i]=parts[i].replace(a,b)
    memo.write_text(''.join(parts),encoding='utf-8')
    print(json.dumps({'sources':len(ledger),'unique_urls':len({s['url'] for s in ledger}),
                      'memo_words':len(text.split()),'model_assertions':'passed','output':str(HERE)}))


if __name__=='__main__':
    main()
