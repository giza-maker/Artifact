# NURIMI commerce research files

Research date: 27 October 2026. Main recommendation and qualifications: `decision-memo.md`.

- `sources.json`: primary-source ledger with access dates, claims and limitations. Entries can share a URL when different research tracks used it.
- `decision-model.json`: explicit platform judgement scores, cost assumptions, sensitivity case and calculations. Not a vendor quote or performance benchmark.
- `source-audit.json` and `sku-readiness.csv`: current NURIMI source/catalogue readiness. Zero variants pass the proposed release gate; this is not a legal determination about physical stock.
- `audit-and-repeat.py`: read-only source audit and configuration/manufacturing dry run. Requires Python 3.11+ and the original repository folder arrangement.
- `repeatability-results.json`: 19 individual assertions, execution time, input/script/output hashes and narrow claim limitations.
- `proof/`: two separately scoped, deterministic brand packages. SADA is a fictional internal fixture, not a registered or deployed business. No product facts, prices or inventory were invented.
- `evidence/`: dated working research notes, source ledgers, inspected vendor package files, dependency graph and trial status. Working notes are not additional approved recommendations.
- `package-evidence.py`: original packaging script; its temporary-source inputs may no longer exist on another computer. Not required to rerun the local audit.

From this folder:

```powershell
python audit-and-repeat.py
```

Or invoke the script using an absolute path. It finds the existing `nurimi/` folder relative to itself and writes only inside this research folder. It never deploys, connects a merchant account, processes payments or updates public files.

Current confirmed planning context: Saudi warehouse/stock partner; merchant registration and business banking are not confirmed. Provider approvals, product evidence and warehouse performance remain launch gates.

No production merchant checkout, refund, stock-race, native-Arabic participant study, field-performance test or second-store deployment was completed by this research. Their proposed acceptance criteria are in the memo.


Build-path supplement (27 Oct 2026): read build-guide.md for managed, hybrid and owned implementation options. Initial decision-memo.md remains the historical fast-launch baseline. sources.json includes additional official capability references. No new merchant or live-commerce tests implied.


Direct comparison supplement (27 Oct 2026): Managed vs custom uses one common basis across models, preserves route estimates, flags conflicting choices, and lists cash/evidence/exit gaps. Technical subtotals exclude retail cash and transaction costs even when other allowances are priced. comparison/ contains reproducible calculation code and focused tests; no private browser notes are included.
