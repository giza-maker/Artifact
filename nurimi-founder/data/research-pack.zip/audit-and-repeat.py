"""Read-only NURIMI audit and platform-neutral brand packaging proof.

No credentials, commercial values, merchant writes or checkout simulation.
Run with Python 3.11+. Output stays beside this script, outside public nurimi/.
"""
from pathlib import Path
from collections import Counter
import csv
import hashlib
import json
import re
import time
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SITE = ROOT / 'nurimi'
OUT = HERE / 'proof'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def product_blockers(product):
    missing = []
    if product.get('localVerification') != 'verified':
        missing.append('exact_local_variant_not_verified')
    price = product.get('price')
    if isinstance(price, bool) or not isinstance(price, (int, float)) or price <= 0:
        missing.append('verified_positive_selling_price_missing')
    stock = product.get('stock')
    if isinstance(stock, bool) or not isinstance(stock, int) or stock < 0:
        missing.append('verified_nonnegative_stock_missing')
    for field in ('batch', 'expiry'):
        if not product.get(field):
            missing.append(f'{field}_missing')
    # Absence from prototype isn't evidence of absence in a future merchant system.
    for field in ('barcode', 'supplierInvoiceReference', 'localListingReference'):
        if not product.get(field):
            missing.append(f'{field}_not_in_current_dataset')
    return missing


def manufacture(config, products):
    selected = [p for p in products if p['id'] in config['product_ids']]
    assert len(selected) == len(config['product_ids']), 'unknown product ID'
    assert set(config['locales']) == {'ar', 'en'}
    assert config['storage_namespace'] == f"{config['id']}:"
    assert config['order_system'] == 'merchant_platform_pending'
    assert len(config['sections']) == len(set(config['sections']))
    assert 'catalog' in config['sections']
    assert all(re.fullmatch(r'#[0-9A-Fa-f]{6}', c) for c in config['tokens'].values())
    folder = OUT / config['id']
    write_json(folder / 'brand.json', config)
    write_json(folder / 'catalog.draft.json', {'status': 'NOT_PUBLISHABLE', 'products': selected})
    css = ':root {\n' + ''.join(f'  --brand-{k}: {v};\n' for k, v in config['tokens'].items()) + '}\n'
    (folder / 'tokens.css').write_text(css, encoding='utf-8')
    public = [p for p in selected if not product_blockers(p)]
    write_json(folder / 'publication-manifest.json', {
        'store_id': config['id'], 'status': 'BLOCKED_PENDING_MERCHANT_AND_SKU_VERIFICATION',
        'eligible_product_ids': [p['id'] for p in public],
        'platform_import_executed': False,
        'merchant_settings_validated': False,
        'source_catalog_sha256': digest((SITE / 'data/products.json').read_bytes()),
        'maker_labels_preserved': True,
    })
    return folder


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    products = json.loads((SITE / 'data/products.json').read_text(encoding='utf-8'))['products']
    details = json.loads((SITE / 'data/product-breakdowns.json').read_text(encoding='utf-8'))['products']
    before = {str(p.relative_to(SITE)): digest(p.read_bytes()) for p in SITE.rglob('*') if p.is_file()}
    audit = {
        'research_date': '2026-10-27', 'source': str(SITE), 'sku_variants': len(products),
        'makers': dict(Counter(p['brand'] for p in products)),
        'null_fields': {k: sum(p.get(k) is None for p in products) for k in ('price','stock','batch','expiry')},
        'local_verification': dict(Counter(p.get('localVerification') for p in products)),
        'missing_barcode_records': sum(not p.get('barcode') for p in products),
        'matching_breakdown_records': sum(p['id'] in details for p in products),
        'catalogue_eligible_for_production': sum(not product_blockers(p) for p in products),
        'frontend_findings': {
            'cart_storage': 'browser localStorage; prototype only',
            'checkout': 'client-rendered sample confirmation; no transmitted order/payment',
            'products': 'static JSON fetched by shop.js',
            'product_urls': 'dialog state; no independent product routes',
            'canonical': 'one GitHub Pages URL',
            'source_locations': ['shop.js:12','shop.js:18','shop.js:190','shop.js:202','shop.js:257','index.html:7'],
        },
        'reuse': ['identity assets','font files','approved Arabic and English copy','23 generated scenes',
                 'original packaging references','source-linked product breakdowns','responsive layout direction'],
        'replace': ['demo bag','sample checkout','static price/stock as operational truth',
                    'single document product routing','public brand-studio navigation in production store'],
    }
    write_json(HERE / 'source-audit.json', audit)
    with (HERE / 'sku-readiness.csv').open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['id','maker','english_name','status','blocking_evidence'])
        for p in products:
            writer.writerow([p['id'],p['brand'],p['name']['en'],'NOT_VERIFIED', '; '.join(product_blockers(p))])

    configs = [
        {
            'id': 'nurimi', 'name': {'ar':'نوريمي','en':'NURIMI'},
            'scenario': 'existing retailer; production operational details pending',
            'locales':['ar','en'], 'default_locale':'ar', 'storage_namespace':'nurimi:',
            'tokens': {'ink':'#3B2158','paper':'#FFF9F3','accent':'#B82B55'},
            'sections':['brand_story','maker_showcase','catalog','product_clarity','delivery_returns'],
            'product_ids':[p['id'] for p in products],
            'order_system':'merchant_platform_pending', 'stock_policy':'per_store_allocated',
            'identity_legal_clearance':'pending',
        },
        {
            'id': 'sada-internal-test', 'name': {'ar':'سادة — اختبار داخلي','en':'SADA — internal test'},
            'scenario': 'fictional second retailer; value-led body care; no commercial/market validation',
            'locales':['ar','en'], 'default_locale':'ar', 'storage_namespace':'sada-internal-test:',
            'tokens': {'ink':'#152C34','paper':'#F7FAF8','accent':'#125C48'},
            'sections':['value_proposition','catalog','delivery_returns'],
            'product_ids':['P022','P023'],
            'order_system':'merchant_platform_pending', 'stock_policy':'per_store_allocated',
            'identity_legal_clearance':'fictional_test_only',
        },
    ]
    started = time.perf_counter()
    paths = [manufacture(c, products) for c in configs]
    elapsed = time.perf_counter() - started
    checks = []

    def check(name, condition):
        checks.append({'name': name, 'passed': bool(condition)})

    check('23 variants read from actual source', len(products) == 23)
    check('unique source IDs', len({p['id'] for p in products}) == len(products))
    check('all 23 source breakdowns matched', all(p['id'] in details for p in products))
    check('missing commercial facts fail publication', audit['catalogue_eligible_for_production'] == 0)
    check('separate storage namespaces', len({c['storage_namespace'] for c in configs}) == 2)
    check('distinct layouts through configuration', configs[0]['sections'] != configs[1]['sections'])
    check('distinct merchandise scope through configuration', configs[0]['product_ids'] != configs[1]['product_ids'])
    check('distinct visual tokens through configuration', configs[0]['tokens'] != configs[1]['tokens'])
    for c, folder in zip(configs, paths):
        first = {p.name: digest(p.read_bytes()) for p in folder.iterdir()}
        manufacture(c, products)
        second = {p.name: digest(p.read_bytes()) for p in folder.iterdir()}
        check(c['id'] + ': deterministic output', first == second)
        exported = json.loads((folder / 'catalog.draft.json').read_text(encoding='utf-8'))['products']
        check(c['id'] + ': exact source records preserved', all(p in products for p in exported))
        check(c['id'] + ': no invented prices or stock', all(p['price'] is None and p['stock'] is None for p in exported))
        check(c['id'] + ': zero unverified records eligible', not json.loads((folder / 'publication-manifest.json').read_text())['eligible_product_ids'])
    bad = dict(configs[1], product_ids=['UNKNOWN'])
    try:
        manufacture(bad, products)
        check('unknown product IDs rejected', False)
    except AssertionError:
        check('unknown product IDs rejected', True)
    bad = dict(configs[1], storage_namespace='nurimi:')
    try:
        manufacture(bad, products)
        check('cross-store namespace collision rejected', False)
    except AssertionError:
        check('cross-store namespace collision rejected', True)
    after = {str(p.relative_to(SITE)): digest(p.read_bytes()) for p in SITE.rglob('*') if p.is_file()}
    check('all existing public files unchanged', before == after)
    proof = {
        'kind':'platform_neutral_configuration_dry_run', 'checks':checks,
        'executed_at_utc':datetime.now(timezone.utc).isoformat(),
        'reproduce_command':'python audit-and-repeat.py',
        'script_sha256':digest(Path(__file__).read_bytes()),
        'input_sha256':{str(p.relative_to(SITE)):digest(p.read_bytes()) for p in
                        [SITE/'data/products.json', SITE/'data/product-breakdowns.json']},
        'fixture_ids':[c['id'] for c in configs],
        'output_sha256':{str(p.relative_to(OUT)):digest(p.read_bytes()) for p in OUT.rglob('*') if p.is_file()},
        'passed':sum(c['passed'] for c in checks), 'failed':sum(not c['passed'] for c in checks),
        'machine_generation_seconds':round(elapsed,4),
        'elapsed_excludes':'research, configuration authoring, merchant onboarding, theme porting and deployment',
        'production_store_deployed':False, 'payment_or_order_tested':False,
        'platform_roundtrip_tested':False,
        'what_this_proves':'same packager produces deterministic, separately scoped brand artifacts; unknown SKU facts remain blocked',
        'what_this_does_not_prove':'Salla/Zid/Shopify deployment, checkout, payment correctness, inventory isolation or second-brand launch lead time',
    }
    write_json(HERE / 'repeatability-results.json', proof)
    assert proof['failed'] == 0, proof
    print(json.dumps({'sku_variants': len(products), 'production_ready':audit['catalogue_eligible_for_production'],
                      'checks_passed':proof['passed'], 'checks_failed':proof['failed'], 'output':str(HERE)}))


if __name__ == '__main__':
    main()
