# NURIMI commerce options: Shopify theme, Shopify headless, Medusa

Research date: 2026-10-27. Scope: Saudi own-inventory skincare, 23 SKUs plus variants, Arabic/English, branded mostly-static storefront, with possible repetition across distinct retailers under one owner. Evidence is official Shopify, Medusa, or payment-provider documentation; prices and provider availability require reconfirmation before contracting.

## Executive read

The three routes solve different problems. A Shopify theme is the lowest-operational-load route. Shopify headless preserves Shopify operations and checkout but adds frontend engineering. Medusa gives maximum ownership and reuse but makes the owner responsible for storefront, Saudi payments, hosting, upgrades, security, and operational correctness.

For this small catalog, neither API scale nor product modeling justifies headless by itself. The decisive unknown is a live Saudi payment proof: mada and Apple Pay behavior, refund path, settlement, fees, and whether checkout is native or redirected. Shopify Payments is **not listed for Saudi Arabia** as of research date, so a Saudi Shopify store needs a third-party gateway. That adds both gateway fees and Shopify's third-party transaction fee.

Indicative launch-fit scores—not final recommendations:

| Option | Launch fit /10 | Strongest case | Principal cost/risk |
|---|---:|---|---|
| Shopify native theme | 8.5 | Fast branded bilingual launch; hosted operations | Saudi gateway UX/fees; per-store duplication |
| Shopify headless | 6.5 | Bespoke UX impossible in Liquid; existing frontend team | Same payment constraint plus two-surface maintenance |
| Medusa custom | 5.5 | Reusable owned platform across many brands; deep workflows | PSP and operations engineering; multi-brand isolation is custom |

## Shopify: native theme

**Fit.** Shopify itself says headless should be considered when themes/apps cannot achieve the experience and warns that headless costs more to build and run. For 23 SKUs, a well-chosen Online Store 2.0 theme can carry bespoke typography, photography, sections, product metafields, bundles/app integrations, and a mostly static editorial surface without introducing a separate runtime.

Arabic and English can live in one store. Markets supports language/domain assignment via subfolder, subdomain, or separate domain; Shopify emits hreflang. Translate & Adapt covers products, collections, pages, policies, and theme content, with manual or machine translation. Arabic requires a theme that actually supports RTL; Shopify explicitly tells merchants to verify RTL layout. Free Shopify themes include language selectors. Translation gaps remain: tags, some filters/forms, manual-payment instructions, and third-party app content may not be translatable. Legal/policy text is manual-only and should be professionally reviewed.

**Saudi payments.** Saudi Arabia is absent from Shopify Payments' supported-country list. A third-party provider must therefore be used. Current Saudi pricing page shows, on annual billing, Basic **US$19/month**, Grow **US$54/month**, Advanced **US$299/month**, and Plus from **US$2,300/month**; monthly billing is higher (for example Basic US$27, Grow US$72, Advanced US$399 on the current Saudi POS/pricing surface). The page shows Shopify third-party transaction fees of **2% / 1% / 0.6% / 0.2%** respectively, paid in addition to the gateway's own commercial rate. Shopify billing for a Saudi store is subject to 15% VAT unless a valid VAT registration makes the bill eligible for exemption. Promotions and USD/local-tax treatment can change; capture a dated checkout quote.

mada/Apple Pay are not properties of “Shopify” in Saudi Arabia; they depend on the exact provider, merchant approval, plugin type, currency, device/browser, and Shopify payment-app constraints. Tap's official support says its Shopify plugin can enable Apple Pay for eligible Saudi businesses in SAR, with native-checkout and redirect plugin variants. PayTabs says its Shopify plugin supports mada but not Apple Pay under Shopify payment-app rules, and uses a redirected payment page. These conflicting provider-specific capabilities make a production-like proof mandatory. Shopify's country-filtered gateway directory is the source of truth for whether a provider can currently be activated, but activation in the actual store admin is the final test.

**Basic versus Grow fee break-even.** Using Shopify's verified annual-billing difference of US$35/month, an explicit planning FX rate of **SAR 3.75/USD**, and the one-percentage-point lower third-party transaction fee, Grow breaks even at **SAR 13,125/month of Shopify fee-bearing order value**: `35 × 3.75 ÷ 0.01`. On monthly billing, the verified US$45 difference gives **SAR 16,875/month**. “Fee-bearing order value” is more precise than product GMV: Shopify's formula is `[(product cost − discounts) + tax + shipping] × rate`. The thresholds exclude Shopify-billing VAT; if NURIMI actually pays 15% VAT on the plan difference and cannot recover it, they rise to SAR 15,093.75 and SAR 19,406.25 respectively. They also exclude gateway pricing. PSP fees cancel from this comparison only if the same PSP rate applies on both plans; obtain a quote rather than assume it.

**Operations.** Shopify provides order/refund/return administration, shipping profiles/rates, inventory, notifications, and a hosted checkout. Actual refund capability and PSP fee return depend on the gateway; refunding in Shopify does not prove the PSP supports the full API path. Shopify's refund guide says that when Shopify Payments is unavailable in the store's country—as in Saudi Arabia—Shopify transaction fees are credited proportionally **only when the refund is issued through Shopify admin**; a refund performed only in the gateway gets no Shopify fee credit. This is more specific than Shopify's general transaction-fee page, which says fees are not returned, so validate the Saudi bill with a real refund and obtain written Support confirmation. Gateway processing-fee refund policy remains separate and unknown. Shipping carriers, COD, return labels, Saudi address format, VAT invoices, and ZATCA obligations must be separately validated. Do not infer Saudi compliance from platform availability.

**Rollback and exit.** Duplicate/download a theme before changes and keep theme source in Git for code rollback. Shopify's “backup” model is manual CSV exports plus theme copy/download or an app. Products, customers, orders, gift-card codes, discounts, and financial data can be exported, but restoration is incomplete: orders cannot be imported through admin; issued gift cards, discount codes, custom reports, traffic, apps, menus, settings, tax/shipping/checkout/payment configuration do not simply restore. This is exportability, not point-in-time disaster recovery.

## Shopify: headless

Headless separates storefront from Shopify backend. Storefront API supplies products, search and cart; checkout is handed to Shopify. Hydrogen is Shopify's preferred React stack; Oxygen hosting is included on paid plans, though its worker runtime has limits and is not a full Node server. Self-hosting is allowed.

Benefits: total rendering/control, reusable design system, custom CMS composition, independent releases, and multiple storefront clients. Costs: build/deployment/observability, preview and caching design, locale/RTL implementation, analytics continuity, customer-account integration, SEO, accessibility, and API-version maintenance. It does **not** remove Shopify subscription, gateway, checkout, transaction-fee, store-isolation, or data-backup constraints. It should be chosen for a requirement the theme cannot satisfy—not merely a premium visual identity.

API risk is manageable at this scale. Storefront API has no fixed per-minute limit for genuine buyer traffic, though bots and checkout creation are throttled and tokenless queries have complexity 1,000. GraphQL Admin API uses cost buckets: standard 100 points/sec, Advanced 200, Plus 1,000; bulk operations handle large exports. Shopify versions APIs quarterly and supports each stable version for at least 12 months; unsupported calls fall forward, which can silently change behavior. **2026-10 is confirmed as the latest stable version on 2026-10-27 and remains accessible through 2027-10-16.** Pin versions, monitor deprecations, test webhooks, and keep repeatable exports.

One Shopify backend may serve multiple headless storefronts, but this is channel presentation, not hard retailer isolation. Headless storefronts share the store's data and API permissions. If distinct retailers require separate legal seller, payouts, orders, customers, prices, apps, staff permissions, or data residency, use separate stores or formally design shared-tenancy rules.

## Repeating retailers on Shopify

Standard Shopify subscriptions are store-scoped: each brand/store needs its own plan, apps, configuration, and paid-theme license. Markets is for regional/language/currency experiences of one merchant/catalog; it is not a multi-brand or separate-retailer boundary.

Shopify Plus includes one main plus up to nine expansion stores under one contract. Official guidance positions expansion stores for the same brand's regions, product-line extensions, B2B, VIP, or retail locations. Each store still operates independently: products, collections, inventory, settings, and configurations do not sync by default; apps bill per store; themes require per-store licenses. Exceeding contract limits requires approval and extra fees. For unrelated brands or genuinely distinct retailers, obtain written Shopify confirmation that expansion-store use fits contract terms rather than assuming “same owner” is sufficient.

## Medusa custom/open-core

Medusa v2 is headless: Express HTTP routes call workflows, which coordinate isolated commerce modules backed commonly by PostgreSQL. **Correction:** Medusa **v2.22.0**, released 2026-10-21, is current evidence and requires Node.js **22.22.0 or later**; the earlier Node 20.19+/22.12+ installation requirement applies to older v2 releases. PostgreSQL remains required. Production infrastructure is modular: Redis-backed event bus, workflow engine, caching, and locking are the documented production choices; local/in-memory providers are development choices. Object storage, transactional email, CDN/WAF, secrets, monitoring, backups, deployment, migrations, and incident response remain owner responsibilities when self-hosted.

Core commerce covers products/variants, pricing, promotions, carts, orders, returns/refunds workflows, inventory reservations, stock locations, regions, sales channels, taxes, fulfillment, and translations. Inventory is reserved when ordering and deducted on fulfillment. Redis locking/event/workflow infrastructure matters once multiple application processes or workers handle concurrent carts/orders. A 23-SKU launch is unlikely to be compute-expensive; engineering and reliability dominate cost.

**Payments.** Medusa's only documented first-party payment provider is Stripe; the built-in `system` provider is a manual/COD placeholder. Saudi mada/Apple Pay therefore require a maintained community provider or a custom Payment Module Provider implementing authorization, capture, refund, cancellation, webhooks, idempotency, reconciliation, and failure recovery against a PSP such as Tap/PayTabs/another contracted provider. “PSP has an API” is not equivalent to production support. Obtain provider certification requirements and run the same live-device acceptance matrix. Medusa avoids Shopify's extra transaction percentage, but PSP fees and custom integration/maintenance remain.

**Multiple brands.** Sales channels can scope products, orders, stock locations, and publishable API keys, enabling multiple storefronts against one server. Medusa v2.22 adds multiple payment-provider accounts per region or sales channel, reducing one earlier credential-routing limitation. It still does not create native multi-tenancy. The Store Module can model multiple stores only with custom links and guards; default Admin APIs expose one default-store-oriented flow, and documentation warns product availability in a sales channel alone does not prevent purchase unless enforced. Shared-instance brands therefore need explicit tenant scoping for every query/mutation, admin role, customer, order, promotion, payment credential, webhook, export, and audit trail. Separate Medusa deployments/databases provide stronger isolation but multiply operations. Shared inventory can be valuable if legally and operationally intended; otherwise it is a leak vector.

**Hosting/licensing.** Self-hosted core is open-core: the core remains MIT, while listed RBAC-based Enterprise materials require a commercial agreement as of v2.19+. Review `ENTERPRISE-LICENSE.md` for the chosen version; do not describe the entire current repository as unrestricted MIT. Medusa Cloud currently lists Develop from $29, Launch from $99, Scale from $299, Enterprise custom, with no GMV platform fee. Important gates: Develop lacks Redis, autoscaling, automatic backups and custom domains; Launch adds Redis, autoscaling and seven-day point-in-time backups; Scale adds workers and 14-day retention. Self-hosted infrastructure may be cheaper in invoices but requires owned on-call and tested backups/restores.

## Future-facing, not launch-blocking

Shopify's Agentic Storefronts and Universal Commerce Protocol became material in 2026: official June/October updates describe product discovery and checkout across AI surfaces and Shop MCP. Current channel eligibility emphasizes selling to US buyers, and APIs changed quickly (Storefront MCP catalog/cart tools were removed in favor of UCP). Medusa documents an Agentic Commerce integration recipe and generic channel architecture. This is useful future optionality, not a launch reason for a Saudi-focused 23-SKU store. Launch priorities remain complete structured product data, correct bilingual claims, payment conversion, fulfillment, privacy, and returns.

## Rejection and reversal tests

- Reject Shopify theme if a signed UX requirement cannot be implemented accessibly in Liquid/theme extensions, or if live Saudi gateway testing shows unacceptable mada/Apple Pay conversion/refund behavior.
- Reverse Shopify headless to a theme if custom frontend work is mainly visual, release cadence becomes dependent on engineers, or checkout/locale/customer-account seams harm conversion.
- Reject shared Shopify store/Markets for separate retailers when legal seller, payouts, customer/order access, pricing, or app permissions must be isolated.
- Reject Medusa for launch if no owner accepts 24/7 platform responsibility, no production-grade Saudi PSP adapter is proven, or tenant-isolation tests are absent.
- Reverse a shared Medusa instance to per-brand deployments if cross-brand permissions, payment credentials, exports, or operational ownership diverge.
- Revisit Medusa/headless when repeated retailers create enough shared custom workflow value to outweigh platform engineering—not merely because the second brand exists.

## Critical unknowns to close with evidence

1. Exact Saudi legal entity, settlement bank, product category, VAT/ZATCA position, and merchant-of-record per retailer.
2. Which gateways appear inside a newly created Saudi Shopify admin today; written PSP quotes including gateway fees, settlement, reserves, chargebacks, refunds, and onboarding.
3. Live mada + Apple Pay matrix: iPhone/Safari and other devices, debit/credit mada, native versus redirect, 3DS, partial/full refund, webhook replay, failed capture.
4. Required shipping carriers, COD rules, label/return integration, delivery SLAs, and cross-border intent.
5. Whether brands share stock, customers, support team, promotions, fulfillment, payment settlement, and reporting—or require hard isolation.
6. Expected number/timing of retailers and who owns recurring frontend/backend/on-call maintenance.
7. Design requirements that demonstrably exceed an RTL-capable Shopify theme.
8. Required RPO/RTO, retention, audit log, privacy deletion, and tested restore/export obligations.

