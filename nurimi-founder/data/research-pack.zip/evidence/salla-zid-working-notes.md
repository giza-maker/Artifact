# Salla vs Zid for NURIMI production commerce

Research date: 2026-10-27. Scope: Saudi own-inventory skincare startup, 23 SKU variants, Arabic/English branded storefront, then repeated distinct brands under same owner. Official vendor material only. No account creation, purchase, or live mutation.

## Decision

**Choose Salla Pro for the first production store**, unless a short paid proof proves Zid Vitrin materially faster for the exact design. Salla has the clearest current merchant path: SAR 2,990/year, Pro-gated code customization, staff controls, theme duplication/preview/scheduled publishing, product/order export, online payments, multilingual storefront, and explicit linked-store switching. For 23 variants, platform scale is irrelevant; reliable merchant operations and repeatability dominate.

Salla is not automatically a reusable multi-tenant brand platform. Linked Stores unifies login/switching, not subscriptions, inventory, theme licensing, or data. Budget and operate each brand as a separate store until Salla confirms otherwise in writing. Build a portable design/content manifest outside platform and maintain exports.

Zid is credible, locally strong, and has a more explicit current developer workflow: Vitrin CLI + private development stores + preview/validate. But merchant production acceptance is costlier/less certain: public help says custom themes require Professional or a separately purchased annual custom-theme add-on; Professional is quote-only. API access is also shown as Professional on current pricing. That makes repeat-brand cost and rollout terms unknown before sales confirmation.

## Commercial plans and gates

### Salla

- Current pricing page/search snapshot: Basic free; Plus **SAR 990/year**; Pro **SAR 2,990/year**. Annual display says 16% saving. Special is quote-only. Public page did not clearly state whether displayed prices include Saudi VAT; obtain tax-inclusive written quote/invoice before purchase.
- Basic: unlimited products/orders/customers; bank transfer/COD. Online payments require paid Plus/Pro. Plus adds electronic payments, local/global shipping, custom domain, more product types. Pro adds staff accounts/management, VAT activation, integrations, and CSS/JS customization.
- Current Help Center says code customization requires **Pro or Special + custom domain + Store Design permission**. Thus NURIMI's fully branded production path is Pro unless an off-the-shelf theme is sufficient.
- New stores get a 14-day Plus/Pro trial. Treat it as feature evaluation, not production continuity.
- Each brand: official multi-store feature links stores under one login on all plans, but docs do not state shared subscriptions, shared inventory, or one theme entitlement across stores. Assume per-store commercial scope; confirm in writing.

### Zid

- Current pricing page: Starter free; Rise **SAR 99/month** or **SAR 990/year**; Growth **SAR 299/month** or **SAR 2,990/year**; Professional quote, paid annually. Page currently mixes campaign values (e.g. 83/249 monthly equivalents, cashback/free-year language) and even renders “990 billed annually” near Starter. Use checkout/sales quote as authority. VAT inclusion is not stated publicly.
- Rise adds one additional manager, ZidPay (mada/Visa/Mastercard), Apple Pay, theme market, custom domain. Growth adds VAT display, five additional staff, two inventories, CSS customization. Professional adds 20 staff, five inventories, external API connectivity.
- Custom theme help (current 2026): production custom theme requires Professional+ **or** purchase of a separate “custom theme” add-on valid one year. Price is not public; expiry removes custom theme and activates default, though file returns after renewal. This renewal failure mode matters.
- No official current evidence found for one owner sharing subscription/theme entitlement across separate Zid stores. Price and feature wording are store-specific. Treat every brand as its own store/subscription/add-on until contracted otherwise.

## Themes, preview, rollout, and reversal

**Salla:** merchant dashboard can duplicate a theme version, independently customize it, preview it, schedule publication, target country/city/language, and revert operationally by activating another saved version. This is strong for campaign rollback. Twilight Marketplace preview-store rules allow 1–4 previews per public theme, but developer demo/preview is not proof that a private custom theme is installable on a merchant plan. Current React Twilight docs are newer than the widely deployed Twig/Raed material; do not choose runtime from docs alone. Require a production-acceptance test: exact package installs on Pro, bilingual pages/checkout work, deployment preserves settings, prior version can reactivate.

**Zid:** Vitrin CLI builds, pushes, previews on a private development store, and validates via `/validate`; preview installs but does not activate. Development store can exercise products, payments, shipping, promotion, RTL and a full order. Production custom-theme activation remains gated as above. Vitrin changelog shows mandatory theme updates for multi-inventory, language/region, Apple Pay quick checkout and bank discounts—budget ongoing maintenance. Reversal: keep last accepted ZIP/version and test activation rollback. Public docs show theme edit/delete/preview but no platform-wide backup/SLA for theme settings.

## Payments, refunds, shipping, returns

- **Salla:** mada, Visa and Apple Pay are public; Apple Pay auto-enables after mada+Visa and appears only on supported Apple/Safari contexts. Basic cannot use electronic payments. Salla publicly states mada **1% + SAR 1** per transaction on a comparison page, with no platform commission; this is promotional, method-specific, and not a complete fee schedule. Actual dashboard fee calculator is authoritative. VAT on fees and fees for Visa/Apple Pay/refunds were not completely public. Payout minimum SAR 100. Full/partial electronic refunds exist; mada often same day, Visa/Mastercard may take ~14 days; after 30 days dashboard refund can be unavailable. Returns can optionally restock items and issue return labels.
- **Zid:** Rise+ exposes mada/Visa/Mastercard and Apple Pay. ZidPay help says fees depend on network and store plan; an example uses mada Growth 1% + SAR 1, then 15% VAT on fees. Official help conflicts: one section says fixed operational fees apply; another says percentage only. Do not quote one universal rate. SAR 3 payout fee, waived for Riyad Bank, minimum payout SAR 100; official pages conflict between three weekly settlement days and daily Sun–Thu wording. Full/partial refund supported with sufficient balance; no extra refund fee beyond original transaction fee; expected 2–7 business days and no dashboard refund after 30 days. Zid checkout docs explicitly say stock is reserved after card details are confirmed and restored on payment/3DS failure; duration and concurrency/oversell guarantees are not published.
- Shipping label headline rates are “from” values, not landed cost: Salla claims 200+ providers; Zid shows Rise from SAR 11, Growth 10.5, Professional 8.5. Test actual NURIMI package dimensions/cities, COD settlement, failed delivery, reverse label, insurer/claims, and return-to-stock behavior.

## API, webhooks, inventory, portability

- **Salla:** OAuth2 scoped access; docs state access token 14 days and refresh window one month. APIs cover products/variants/quantities, orders/reservations, exports, employees, domains, shipments and payments. Product/order export exists in dashboard/API. Rate limiting is universal but official public overview gives no stable numeric global limit; inspect response headers and implement backoff. Webhook docs require token/signature verification; current playbook says respond 2xx quickly, queue work, and design idempotently because retries/duplicates occur. Public docs do not specify retry schedule, ordering, replay, or exactly-once guarantees. Reconcile by periodic export/API reads.
- **Zid:** current official ERP guide states **60 requests/minute per app per store**. Verify signature over raw bytes, use constant-time comparison, durably record, then acknowledge 200/201/202/204. Delivery timeout 10 seconds, up to three attempts/backoff, no ordering/exactly-once, and missed events are not replayed; reconciliation is mandatory. Fresh 2026 update says Basic Authentication became mandatory and reports health/broken/recover endpoints, but official materials conflict on exact retry timing and whether HTTP 429 counts as failure. Test observed behavior, never use 429 as backpressure. Own writes often suppress echo webhooks.
- Both support product variants and inventory. Salla has explicit product import/update export and deleted-product restore; order export templates exist. Zid API supports product/stock/location events and bulk initial sync, but current merchant UI export completeness for images, SEO, translations, variants, policies, redirects and customers was not established from public official docs. Before commitment, export a bilingual 23-variant test catalog and re-import into a clean test store.
- Stock race guarantees remain incomplete. Salla has Order Reservations APIs, but public docs do not define checkout hold TTL/atomicity. Zid documents payment-stage reservation but not TTL/oversell semantics. Load-test last-unit concurrent checkout, failed 3DS, abandoned checkout, COD, refund, cancellation and multi-location allocation.

## Language, SEO, domain, people, recovery

- Both support Arabic/English storefronts and SEO fields. Zid explicitly says English activation does **not** translate merchant content; re-enter products, policies and store text in English. Apply same content QA discipline on Salla. Verify localized URLs, canonical/hreflang, sitemap, robots, metadata, structured data, RTL, fonts, email/SMS and checkout.
- Custom domains: Salla Plus+; Zid Rise+. Salla can transfer Salla-purchased domains between stores; Basic destination rejected. Keep registrar ownership/DNS outside vendor where practical and document cutover/rollback.
- Salla Pro staff roles/permissions are documented; Zid plan counts are clear (Rise +1, Growth +5, Pro +20), but permission granularity needs UI proof.
- Neither vendor publicly promises complete merchant-controlled backups or point-in-time restore. Salla provides theme copies, deleted-product restore and exports; Zid exposes theme versions/ZIP workflow but no complete backup guarantee found. Nightly/weekly off-platform catalog, order, customer, policy, redirects, and theme-source backups are required.
- Status evidence: both have public status pages. On 2026-10-27 both showed operational. Salla records a 1-minute storefront outage on 2025-10-08. Zid recorded a 2026-10-25 import/export partial outage and a 2026-10-09 theme asset outage (~1h42m, according to its postmortem). Subscribe; status history is evidence, not SLA.

## Acceptance plan and reversible commitment

1. Build same NURIMI slice on Salla Pro trial and Zid dev store: 23 variants, AR/EN, policies, SEO, domain staging, mada/Apple Pay sandbox/test path, two shipping zones, refund/return.
2. Demand written Zid Professional/custom-theme-add-on price, VAT, renewal consequence, API eligibility, per-store cloning/license, support/SLA. Demand Salla written VAT-inclusive total, theme runtime/private install acceptance, payment fee table, and per-store/theme reuse terms.
3. Run last-unit race and failure matrix; validate webhook signatures, duplicate delivery, retries, outage reconciliation and exports.
4. Time brand #2 clone from source-controlled tokens/content. Reject any process requiring manual theme surgery or uncaptured dashboard state.
5. Keep domain, media originals, translations, theme source, catalog master and exports platform-neutral. Launch first store monthly/shortest reversible term if available; only annualize after acceptance.

## Bottom line

Salla Pro is fastest defensible default: known annual price, enough customization, stronger merchant-side preview/version operations, clear exports and multi-store switching. Zid may win if Vitrin productivity matters more and sales offers a favorable repeat-store contract, but unknown Professional/add-on price and production-theme/API gates are real decision blockers—not minor paperwork.

## 2026-10-27 runtime correction: React Raed is promising, not yet production-proven here

Independent npm registry checks confirm `@salla.sa/theme-raed@1.0.63` is the current `latest` package and `esbuild@0.28.2` now resolves with a valid registry tarball. Therefore, the earlier `ERR_PNPM_NO_MATCHING_VERSION` must **not** be treated as a bad published dependency. The same install attempt also reported broken-metadata/network timeouts; it proves only that a clean local install/build was not completed in that environment.

The package README itself is materially stricter/newer than the quick-start page: it requires pnpm 10 and Node 22.22.2+, 24.15.0+, or 26+, directs scaffolding through `npx @salla.sa/cli@beta theme create`, and says Salla builds/publishes from the theme repository on its infrastructure. Registry metadata confirms React 19.2.8 and `@salla.sa/twilight-theme-engine ^1.0.127`. This is credible first-party React infrastructure, but beta CLI instruction, documentation/version mismatch, uncompleted clean install, and untested merchant production publication mean it is not yet a safe critical-path commitment.

Correction to recommendation: keep **Salla Pro**, but launch with a vendor-managed proven marketplace theme or a vetted private Twilight/Twig theme plus custom sections/CSS/JS. Run React Raed as a parallel spike only. Promote it after: clean install with the README toolchain, typecheck/tests/production build, Salla review acceptance, install on a Pro merchant store, bilingual checkout/payment/shipping tests, settings preservation across update, and rollback to prior live theme.

Official publication terms clarify private-theme gates but not same-owner reuse rights: developer selects public, beta, or private; private installs only through an installation link; availability can target all or selected stores; every update—including private themes—requires a new Salla review. Official review guidance lists a one-time minimum of SAR 250 for public themes and SAR 1,000 for private themes. “One-time” does not establish a multi-store license. Obtain written confirmation for installing the same private theme into each same-owner brand, per-store charge/commission, source ownership, support/update duty, and what happens when a store changes plan or developer relationship.
