# Source attribution

## Brand artwork

Logo, reverse logo, sparkle, monogram, and PNG preview were digitized from owner-supplied approved NURIMI reference artwork. Private intake references are excluded. Current vector remains concept pending owner optical approval and trademark/legal clearance.

## Packaging concept

`concepts/packaging-CONCEPT.webp` was generated with AI from approved brand references. Concept only; not production artwork, printer-ready dieline, or proof of physical output. Do not extract its rendered logo; use packaged SVG artwork.

## Fonts (not bundled)

- Plus Jakarta Sans: https://fonts.google.com/specimen/Plus+Jakarta+Sans — SIL Open Font License
- Alexandria: https://fonts.google.com/specimen/Alexandria — SIL Open Font License
- Noto Sans Arabic: https://fonts.google.com/noto/specimen/Noto+Sans+Arabic — SIL Open Font License

License texts included under `licenses/`. Tabler Icons MIT license retained for source attribution; icon sprite not included.
