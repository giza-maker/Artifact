# NURIMI brand pack

Concept release — 25 October 2026.

Start with `guide/NURIMI-brand-guide.pdf` or Markdown source. Tokens live in `tokens/`. Editable artwork lives in `brand/`; `logo.png` is convenience artwork, not master. `concepts/packaging-CONCEPT.webp` is presentation-only concept imagery—not production artwork, dieline, print proof, or evidence of physical product.

Logo status: source-derived digitized concept. Owner optical approval, trademark review, and legal clearance remain required before production use.

No font binaries or product imagery bundled. Install fonts from official family pages in `SOURCE-ATTRIBUTION.md`; retain supplied licenses.
