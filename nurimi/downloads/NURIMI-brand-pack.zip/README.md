# NURIMI brand pack

Concept release — 26 October 2026.

Start with `guide/NURIMI-brand-guide.pdf` or its editable Markdown source. Tokens live in `tokens/`. Editable vector artwork lives in `brand/`.

`campaign/` includes generated studio scenery, a texture still and a silent 6.583-second texture film. Prompts and source records live in `campaign/provenance.md`. These images create atmosphere; they do not depict a specific product formula or replace original packaging.

`concepts/packaging-CONCEPT.webp` is presentation-only packaging imagery. Logo artwork is a source-derived digitized concept pending final optical and commercial approval.

No product packshots or font binaries bundled. Install fonts from official family pages in `SOURCE-ATTRIBUTION.md`; retain the licenses.
